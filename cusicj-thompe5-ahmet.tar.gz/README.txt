// Evan Thompson, Jack Cusick, Tausif Ahmed

Operating Systems Homework 4

compile with: g++ server.cpp frame.cpp pagingSys.cpp -Wall -pthread


We had issues linking commands with binary files. All commands seem to work when individually tested with the file, test_page_sys.cpp.

If you would like to run that, run make in the directory and then run ./test.out and it will display all of the test output which is 
correct.  

Please email us for test code if neccessary as we do not know how to put ./storage in our zip
